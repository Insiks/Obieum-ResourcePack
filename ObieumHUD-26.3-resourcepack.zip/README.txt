Obieum HUD font assets; requires ObieumHUD plugin. Merge into an existing pack if one exists.
